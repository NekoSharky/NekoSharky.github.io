import os
from pathlib import Path

# ================== 設定 ==================
BASE_DIR = "."   # 今いるフォルダを対象
# ========================================

def is_numbered_file(filename):
    """1.png, 2.png みたいな形式かどうかチェック"""
    name = Path(filename).stem
    return name.isdigit()

def safe_rename():
    # 画像ファイル一覧取得
    files = [f for f in os.listdir(BASE_DIR) 
             if f.lower().endswith(('.png', '.jpg', '.jpeg', '.webp', '.gif'))]
    
    # すでに正しい連番のものと、変な名前のものに分ける
    numbered = [f for f in files if is_numbered_file(f)]
    to_rename = [f for f in files if not is_numbered_file(f)]
    
    print(f"📁 合計 {len(files)}枚")
    print(f"   すでに連番: {len(numbered)}枚")
    print(f"   リネーム対象: {len(to_rename)}枚\n")
    
    if not to_rename:
        print("✅ すでに全部連番になっています！ これ以上変更しません。")
        return
    
    # 連番の最大値を見つける
    max_num = max((int(Path(f).stem) for f in numbered), default=0)
    start_num = max_num + 1
    
    # ソートしてリネーム（ファイル名順）
    to_rename.sort()
    
    for i, old_name in enumerate(to_rename, start_num):
        ext = Path(old_name).suffix.lower()
        new_name = f"{i}{ext}"
        
        old_path = os.path.join(BASE_DIR, old_name)
        new_path = os.path.join(BASE_DIR, new_name)
        
        os.rename(old_path, new_path)
        print(f"✅ {old_name}  →  {new_name}")
    
    print(f"\n🎉 完了！ {len(to_rename)}個を新しく連番にしました。")

if __name__ == "__main__":
    safe_rename()